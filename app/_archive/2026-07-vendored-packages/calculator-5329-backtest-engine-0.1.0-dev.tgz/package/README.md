# @calculator-5329/backtest-engine

A pure-TypeScript backtest and retirement-simulation engine with **zero runtime dependencies** (a hard constraint). It is the single shared engine consumed by retirement-sim, Fathom, and finance-master, so simulation results are identical everywhere the same inputs appear. The trust story is fixture-first: behavior is pinned by tests against synthetic and public-market data fixtures — this package (and repo) must **never** contain personal financial data.

> Status: pipeline skeleton. The engine itself is being lifted from Fathom in a follow-up task; for now the package exports only `VERSION`.

## Usage

```ts
import { VERSION } from "@calculator-5329/backtest-engine";
```

## License

MIT
